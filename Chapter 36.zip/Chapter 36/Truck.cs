﻿/// <summary>
/// Summary description for Truck
/// </summary>
public class Truck
{
	private string make;//make of truck
	private static int count;//class level field
	public Truck(string name)
	{
		make = name;//set instance field
		count++;//increment instance count
	}
	//control access to static field with static property
	public static int TruckCount
	{
		get
		{
			return count;
		}
	}
}