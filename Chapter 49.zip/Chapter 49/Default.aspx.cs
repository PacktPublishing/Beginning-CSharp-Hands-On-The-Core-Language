﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public enum Days { Monday = 1, Tuesday, Wednesday }; //declare and create an enumeration

public partial class _Default : System.Web.UI.Page
{
	protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
	{
		switch (DropDownList1.SelectedValue) //switch on the selected value
		{
			case "Monday": //Days.Monday gets Monday, and (int)Days.Monday gets "1", likewise below
                sampLabel.Text = $"{Days.Monday} is day number {(int) Days.Monday}";
				break;
			case "Tuesday":
				sampLabel.Text = $"{Days.Tuesday} is day number {(int) Days.Tuesday}";
				break;
			case "Wednesday":
				sampLabel.Text = $"{Days.Wednesday} is day number {(int) Days.Wednesday}";
				break;
		}
	}
}