﻿//printable interface
public interface IPrintable
{
	string Print();//declare one method signature
} //now Person can be used as a
printable object
public class Person : IPrintable
{
	private string name;
	public Person(string nam)
	{
		name = nam;
	}
	public string Print()
	{
		return $"<br>Name:{name}";
	}
} //now document can be used as a
printable object
public class Document : IPrintable
{
	private string text;
	public Document(string t)
	{
		text = t;
	}
	public string Print()
	{
		return "<br>" + text;
	}
}