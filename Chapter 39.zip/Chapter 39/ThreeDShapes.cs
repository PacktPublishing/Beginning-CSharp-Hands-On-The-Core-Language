﻿//because we have System.Math, we can type
//Pow(...) instead of Math.Pow(...)
using static System.Math;
//class represents a concept
public abstract class ThreeDShapes
{
	//all 3d shapes have volume, so makes sense to have
	//a function that represents this abstract concept
	public abstract double GetVolume();
} //Sphere inherits from ThreeDShapes
public class Sphere : ThreeDShapes
{
	private double radius;
	public Sphere(double r)
	{
		radius = r;
	}
	//this function provides a highly specific implementation of GetVolume
	public override double GetVolume()
	{
		return (4.00) / (3.00) * PI * Pow(radius, 3);
	}
} //Cube inherits from ThreeDShapes
public class Cube : ThreeDShapes
{
	private double edge;
	public Cube(double edgeLength)
	{
		edge = edgeLength;
	}
	//this provides a highly specific implementation of GetVolume
	public override double GetVolume()
	{
		return Pow(edge, 3);
	}
}