﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		//make a new sphere object
		Sphere sp = new Sphere(double.Parse(TextBox1.Text));
		//make a new cube object
		Cube cb = new Cube(double.Parse(TextBox2.Text));
		//display volume of sphere
		sampLabel.Text = "Volume of sphere is " + sp.GetVolume();
		//display volume of cube
		sampLabel.Text += "<br>Volume of cube is " + cb.GetVolume();
	}
}