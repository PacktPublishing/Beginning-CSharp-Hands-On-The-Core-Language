﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		double x, y;// variables for reading input
		try
		{
			//both lines below could generate format exceptions
			x = Convert.ToDouble(TextBox1.Text);
			y = Convert.ToDouble(TextBox2.Text);
			if (y == 0)
			{
				//throw a new object of DivideByZeroException type
				throw new DivideByZeroException();
			}
			else
			{
				sampLabel.Text = $"{x}/{y}={x / y}";
			}
		}
		//this catch runs when a user inputs 0
		catch (DivideByZeroException ex)
		{
			sampLabel.Text = ex.Message;
		}
		//this block runs when a user inputs a word like "five" instead of "5"
		catch (FormatException ex)
		{
			sampLabel.Text = ex.Message;
			sampLabel.Text += "<br>" + ex.StackTrace;
		}
		finally
		{
			//this line always runs, no matter what happens above
			sampLabel.Text += "<br>Your operation is complete.";
		}
	}
}