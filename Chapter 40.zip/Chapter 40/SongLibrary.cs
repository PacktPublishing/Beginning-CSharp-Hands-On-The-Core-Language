﻿using System;//namespace import
public class SongLibrary //name of our type
{
	private string[] songs; //instance varialbe is an array
	public SongLibrary(string[] tunes)
	{
		songs = tunes;//set instance variable through parameter
	}
	public SongLibrary SortLibrary()
	{
		Array.Sort(songs);//sort songs array
		return this;//return sorted song library
	}
	public string DisplaySongs()
	{
		string list = null;//make string null at first
		foreach (var str in songs)
		{
			list += $"<br>{str}";//build up results
		}
		return list;//return list
	}
}