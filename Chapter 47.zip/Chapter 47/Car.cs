﻿public class Car
{
	public string MakeModel { get; set; }//auto property
	public string PreviousOwner { get; set; }//auto property
	public Car(string makeModel, string prevOwner)
	{
		//set values of properties inside constructor
		MakeModel = makeModel;
		PreviousOwner = prevOwner;
	}
}