﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Collections.Generic;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		sampLabel.Text = "";//clear label
		List<Car> carList = new List<Car>();//make list of cars
		carList.Add(new Car("Honda,Accord", null));//fill list with new cars
		carList.Add(new Car(null, "Mary Jenkins"));
		carList.Add(new Car("Jeep,Cherokee", "Bob Jones"));
		carList.Add(null);//this one is null, so no car is stored
						  //iterate over the cars inside the list
		foreach (Car c in carList)
		{
			//the operator ?. helps to ensure that nothing is null before it's used
			//the operator ?? allows us to include a default value that shows when things are
			null
		//in lines below, Split returns a string array, so it's allowed to write [0] to
			get the
		//value at index 0, and likewise for the value at index 1
			sampLabel.Text += $"<br>Make:{c?.MakeModel?.Split(new char[] { ',' })[0] ?? "Make
		Not Known"}";
			sampLabel.Text += $"<br>Model:{c?.MakeModel?.Split(new char[] { ',' })[1] ?? "Model
		Not Known"}";
			sampLabel.Text += $"<br>Previous Owner:{c?.PreviousOwner ?? "No Owner Known"}";
			sampLabel.Text +=
			"<br>-------------------------------------------------------------------------- "
			;
		}
	}
}