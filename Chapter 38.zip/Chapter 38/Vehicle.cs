﻿/// <summary>
/// Summary description for Vehicle
/// </summary>
public class Vehicle
{
	//instance variable
	private string make;
	//vehicle constructor
	public Vehicle(string mk)
	{
		make = mk;
	}
	//virtual function that provides some basic featrues
	public virtual string ShowInformation()
	{
		return $"Make:{make}";
	}
}
public class Sedan : Vehicle
{
	private int numberOfDoors;
	public Sedan(string mk, int doors) : base(mk)
	{
		numberOfDoors = doors;
	}
	//this version overrides the virtual one above
	//it calls the base class function, and adds a touch of
	//refinement
	public override string ShowInformation()
	{
		return base.ShowInformation() + " " + $"<br>Number Of Doors:{numberOfDoors}";
	}
}