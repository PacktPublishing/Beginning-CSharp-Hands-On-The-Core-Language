﻿//make parent class
public class Product
{
	//place price here because it's common to all products
	private decimal price;
	//set value of instance variable
	public Product(decimal pri)
	{
		price = pri;
	}
	//make this method virtual
	//because it makes sense to put the display of the price
	//in a centralized location, since the Price is common to all products
	public virtual string GetDesc()
	{
		return $"<br>Price:{price:C}";
	}
}
public class Book : Product
{
	private string title;
	public Book(string t, decimal p) : base(p)
	{
		title = t;
	}
	//override GetDesc from product
	//by providing a more specific implementation that also shows the book title
	public override string GetDesc()
	{
		return base.GetDesc() + $"<br>Title:{title}";
	}
}
public class Shoe :
Product
{
	private string make;
	public Shoe(string mk, decimal p) : base(p)
	{
		make = mk;
	}
	//override GetDesc from product
	//by providing a more specific implementation that also shows the shoe make
	public override string GetDesc()
	{
		return base.GetDesc() + $"<br>Make:{make}";
	}
}