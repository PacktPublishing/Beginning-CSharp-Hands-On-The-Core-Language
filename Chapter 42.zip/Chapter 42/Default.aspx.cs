﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Collections.Generic;//add this for generic lists
								 //public means accessible anywhere
								 //partial means this class is split over multiple files
								 //class is a keyword and think of it as the outermost level of grouping
								 //:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		//make a list of products
		List<Product> lp = new List<Product>();
		//make a book and a shore, and store them inside the list of products
		lp.Add(new Book(TextBox1.Text, decimal.Parse(TextBox2.Text)));
		lp.Add(new Shoe(TextBox3.Text, decimal.Parse(TextBox4.Text)));
		//call the correct, derived version of GetDesc on each product in the list
		lp.ForEach(x => sampLabel.Text += x.GetDesc());
	}
}