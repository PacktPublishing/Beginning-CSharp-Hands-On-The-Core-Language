﻿namespace MathLibrary //define a namespace
{
	public class BasicMath//define a basic math class
	{
		public double Add(double x, double y)//define a basic function like Add
		{
			return x + y;
		}
	}
	//code below is as above, just for a finanicial math class
	public class FinancialMath
	{
		public double GetInterest(double prin, double rate)
		{
			return prin * rate;
		}
	}
}
