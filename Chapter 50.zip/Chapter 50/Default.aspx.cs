﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using MathLibrary;//import features from our Math Library
				  //public means accessible anywhere
				  //partial means this class is split over multiple files
				  //class is a keyword and think of it as the outermost level of grouping
				  //:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		BasicMath bm = new BasicMath();//make a new basic math object
									   //use the Add method on the basic math object
		sampLabel.Text = $"{bm.Add(double.Parse(TextBox1.Text), double.Parse
		(TextBox2.Text))}";
}
protected void Button2_Click(object sender, EventArgs e)
{
	FinancialMath fm = new FinancialMath();//make a new financial math object
										   //use the GetInterest method on the finanical math object
	sampLabel.Text = $"{fm.GetInterest(double.Parse(TextBox3.Text), double.Parse
	(TextBox4.Text))}";
}
}