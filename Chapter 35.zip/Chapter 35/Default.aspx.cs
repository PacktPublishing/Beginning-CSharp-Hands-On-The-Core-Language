﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
class Circle//4. This class functions as a template for making circle objects
{
	private double radius;//5. This is the instance variable that defines each circle object
	public double Radius//6. Radius is the property that represents the radius of a circle
	{
		get
		{
			return radius;//7. This line retrieves the value of a circle radius
		}
		set
		{
			if (value >= 0)//8. Checks whether the value we're attempting to set is more than or equal to 0
			{
				radius = value;//9. This runs if the value being set is ok
			}
			else
			{
				radius = 0;//10. The radius field gets the value 0 when a user attempts, for example, to assign a value like -5
			}
		}
	}
}

public partial class _Default : System.Web.UI.Page
{

	protected void TextBox1_TextChanged(object sender, EventArgs e)
	{
		Circle circ = new Circle();//11. Makes a new circle object
								   //12. Line below uses circ.Radius, which means that the set portion of the property is called
		circ.Radius = double.Parse(TextBox1.Text);
		//13. Because circ.Radius is used, and not SET, the Get portion of the Radius property is called
		Label1.Text = $"Circumference is {2 * Math.PI * circ.Radius}";
	}
}
