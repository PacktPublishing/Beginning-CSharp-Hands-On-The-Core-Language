﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Collections.Generic;//needed for lists
using System.Linq;//needed for functions like Sum
				  //public means accessible anywhere
				  //partial means this class is split over multiple files
				  //class is a keyword and think of it as the outermost level of grouping
				  //:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		List<double> d = new List<double>();//make list
		d.Add(Convert.ToDouble(TextBox1.Text));//add values to list
		d.Add(Convert.ToDouble(TextBox2.Text));
		d.Add(Convert.ToDouble(TextBox3.Text));
		sampLabel.Text = $"Sum={d.Sum()}";//show sum of list
		sampLabel.Text += $"<br>Average={d.Average()}";//show average of list
		sampLabel.Text += $"<br>Min={d.Min()}";//show minimum value of list
		sampLabel.Text += $"<br>Max={d.Max()}";//show maximum value of list
		d.ForEach(x => sampLabel.Text += $"<br>{x}^2={x * x}");//show each x squared
															   //line below shows each x decreased by the average of the list
		d.ForEach(x => sampLabel.Text += $"<br>{x}-{d.Average()}={x - d.Average()}");
	}
}