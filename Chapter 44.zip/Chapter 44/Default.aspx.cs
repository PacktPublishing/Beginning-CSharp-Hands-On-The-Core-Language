﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		sampLabel.Text = "";//clear label
		Records recs = new Records();//make new records object
									 //use for loop to iterate over records object
		for (int i = 0; i < recs.Length; i++)
		{
			//because recs has an internal array,
			//array access notation can be used by writing recs[i]
			sampLabel.Text += "<br>" + recs[i];
		}
	}
}