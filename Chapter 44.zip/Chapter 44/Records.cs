﻿/// <summary>
/// Summary description for Records
/// </summary>
public class Records
{
	//this is the array that is internal
	public double[] records = new double[] { 1, 8, 9, 1, -8, -3, -458 };
	public double this[int i]
	{
		get
		{
			return records[i];//this gets value stored at index i
		}
		set
		{
			records[i] = value;//this sets the value stored at index i
		}
	}
	public int Length
	{
		get
		{
			return records.Length;//used to get length of internal array
		}
	}
}