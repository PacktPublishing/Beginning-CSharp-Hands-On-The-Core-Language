﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Threading;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public delegate void LabelUpdater();//declare delegate
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		LabelUpdater lu = UpdateLabelOne; //make delegate and assign function
		lu += UpdateLabelTwo;//assign another function
		lu += new LabelUpdater(UpdateMainLabel);//assign another function
		lu.Invoke();//invoke delegate
	}
	//this function is called first
	public void UpdateLabelOne()
	{
		labelOne.Text = $"{DateTime.Now}";
		Thread.Sleep(5000);
	}
	//this function is called second
	public void UpdateLabelTwo()
	{
		labelTwo.Text = $"{DateTime.Now}";
		Thread.Sleep(5000);
	}
	//this function is called third
	public void UpdateMainLabel()
	{
		mainLabel.Text = $"Labels finished updating at:{DateTime.Now}";
	}
}