﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Threading;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		Point[] points = new Point[10];//array of points
		for (int i = 0; i < points.Length; i++)
		{
			//line below fills array with new points whose x and y coordinates are random
			points[i] = new Point(new Random().Next(-10, 10), new Random().Next(-10, 10));
			//use thread sleeping to ensure the x and y coordinates are not all the same
			Thread.Sleep(1000);
		}
		//iterate over array of points to show the x and y coordinates
		foreach (Point p in points)
		{
			sampLabel.Text += $"({p.X},{p.Y})";
		}
	}
}