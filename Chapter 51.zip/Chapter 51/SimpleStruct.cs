﻿public struct Point //struct declaration
{
	public double X { get; set; } //auto properties
	public double Y { get; set; }
	public Point(double x, double y)
	{
		X = x; Y = y; //set values of auto properties through constructor
	}
}