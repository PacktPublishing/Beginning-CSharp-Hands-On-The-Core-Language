﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public struct Point
{ //make struct with auto implemented properties
	public double X { get; set; }
	public double Y { get; set; }
	public Point(double x, double y)
	{
		X = x; Y = y;//assign properties inside constructor
	}
}
public partial class _
Default :
System.Web.UI.Page
{
protected void Button1_Click(object sender, EventArgs e)
{
	Point p1 = new Point(1, 2); //make point
	Point p2 = p1;//copy p1 to p2
	sampLabel.Text = $"P1=({p1.X},{p1.Y})";//print p1
	sampLabel.Text += $"<br>P2=({p2.X},{p2.Y})";//print p2
	p1.X = 25; p1.X = 35;//change p1
	sampLabel.Text += $"<br>P1=({p1.X},{p1.Y})";//print updated p1
												//line below still prints (1,2) because structs are copied by value
												//so updating p1 has NO effect on the x and y values of p2
	sampLabel.Text += $"<br>P2=({p2.X},{p2.Y})";//this still prints 1,2
}
}