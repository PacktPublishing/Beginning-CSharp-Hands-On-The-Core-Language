﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	//dynamic means this function can operate on a wide variety of data types
	private static dynamic Increase(dynamic x)
	{
		return x * 1.1;
	}
	protected void Button1_Click(object sender, EventArgs e)
	{
		//z is given a double
		dynamic z = Convert.ToDouble(TextBox1.Text);
		sampLabel.Text = $"{z} increased by 10% is {Increase(z)}";
		//the type of variable z can be changed, z is given an integer now
		z = Convert.ToInt32(TextBox2.Text);
		sampLabel.Text += $"<br>{z} increased by 10% is {Increase(z)}<br>";
		//title is recognized as storing a string
		var title = "Welcome";
		Page.Title = title;//set title of page
						   //title = 25; this is not possible because title is already recognized as a string
						   //var can be used in foreach loops and other contexts
		foreach (var c in Page.Title)
		{
			//c.ToString() runs first, and then the result is converted to upper case
			//and finally the result is displayed on the screen
			sampLabel.Text += $"{c.ToString().ToUpper()}";
		}
	}
}