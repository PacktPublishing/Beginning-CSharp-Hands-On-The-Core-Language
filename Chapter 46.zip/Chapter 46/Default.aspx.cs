﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
using System.Collections.Generic;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		sampLabel.Text = "";//clear label every time
		List<Book> bookList = new List<Book>();//make list books
											   //fill list of books using named paramters
		bookList.Add(new Book(title: "Moby Dick", publicationDate: 1851));
		bookList.Add(new Book("13 Steps To Riches", DateTime.Now.Year, "eBook"));
		bookList.Add(new Book(publicationDate: 1937, title: "Think And Grow Rich"));
		//line below searches for all matching books based on what's entered in the text box
		List<Book> searchResults = bookList.FindAll(book => book.Title.ToLower().Contains (TextBox1.Text.ToLower()));
		//line below prints each book by calling ToString() on each book
		searchResults.ForEach(book => sampLabel.Text += book.ToString());
	}
}
