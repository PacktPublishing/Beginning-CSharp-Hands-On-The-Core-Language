﻿using System;
public class Book
{
	public string Title { get; set; }//create automatic property
	string bookType;
	int pubDate;
	public Book(string title, int publicationDate, string type = "Traditional Book")
	{
		Title = title;//set value of automatic property
		pubDate = publicationDate;
		bookType = type;
	}
	//override tostring to display book info
	public override string ToString()
	{
		return $"Title:{Title}<br>Type:{bookType}<br>Publication Date:{pubDate}";
	}
}