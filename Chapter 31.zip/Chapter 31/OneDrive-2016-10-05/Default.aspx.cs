﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{

    protected void Button1_Click(object sender, EventArgs e)
    {
        double[,] arr = new double[2, 2];//5. Declares and sets 2 by 2 array, 2*2=4, so array has 4 cells
        arr[0, 0] = 45; arr[0, 1]=34;//6. Filling the first row, which has an index of 0, column indexes go from 0 to 1
        arr[1, 0] = 23;arr[1, 1] = 78;//7. Filling second row, which has index 1, column indexes go from 0 to 1
        double sum = 0;//8. Begin with a value of 0 so the sum is not changed

        foreach (double d in arr)//9. This means grab each entry one at a time
            sum += d;//10. Add the entries together

        sampLabel.Text = $"Sum is {sum}";//11. Prints sum to web page

        //12. Line below prints entry at index 0,1 formatted as currency
        sampLabel.Text += $"<br>The value at index (0,1) formatted as currency is {arr[0, 1]:C}";
    }
}

