﻿//2+4=6
//"Hello"+" World"="Hello World"
//<1,2>+<2,4>=<3,6>
public class Vector
{
	public double XCoord { get; set; } //define auto properties
	public double YCoord { get; set; }
	public Vector(double x, double y)
	{
		XCoord = x; YCoord = y; //set values of auto properties
	}
	//this is the operator
	//it returns a vector that is the sum of the other two
	public static Vector operator +(Vector vec1, Vector vec2)
	{
		//this is the steps that constructs a new vector
		return new Vector(vec1.XCoord + vec2.XCoord, vec2.YCoord + vec2.YCoord);
	}
	//because the default vesion of ToString() would give a crappy
	//representation of vectors, we override it here
	public override string ToString()
	{
		return $"<{XCoord},{YCoord}>";
	}
}