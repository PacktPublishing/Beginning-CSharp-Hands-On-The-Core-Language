﻿//using is a directive
//System is a name space
//name space is a collection of features that our needs to run
using System;
//public means accessible anywhere
//partial means this class is split over multiple files
//class is a keyword and think of it as the outermost level of grouping
//:System.Web.UI.Page means our page inherits the features of a Page
public partial class _Default : System.Web.UI.Page
{
	protected void Button1_Click(object sender, EventArgs e)
	{
		Vector vec1 = new Vector(1, 2);//define three new vector
		Vector vec2 = new Vector(3, 4);
		Vector vec3 = new Vector(5, 6);
		Vector[] vecs = new Vector[] { vec1, vec2, vec3 };//make an array of vectors
		foreach (Vector v1 in vecs)//this loop fixes each vector
		{
			foreach (Vector v2 in vecs)//this one adds the other two, one by one, to the fixed
				one
		{
				//this line displays the vectors, and the sum of the vectors
				sampLabel.Text += $"<br>{v1.ToString()}+{v2.ToString()}={(v1 + v2).ToString
				()}
			";
		}
	}
}
}